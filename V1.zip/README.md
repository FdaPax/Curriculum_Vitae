# Curriculum_Vitae

¿Qué tipo de patrón usaste para el proyecto?
¿Por qué decidiste utilizar este patrón y no otro?
¿Qué tecnología y/o estrategias usarás para que la maqueta sea responsiva?